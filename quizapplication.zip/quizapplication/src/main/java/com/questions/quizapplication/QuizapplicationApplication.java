package com.questions.quizapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.questions.quizapplication")
public class QuizapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizapplicationApplication.class, args);
	}

}
