package com.questions.quizapplication.enums;

public enum DifficultyLevel {

	
	EASY,
	MEDIUM,
	HARD
}
