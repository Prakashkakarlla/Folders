package com.questions.quizapplication.service;

import java.util.List;

import com.questions.quizapplication.entities.QuestionWrapper;

public interface QuizService {
	
	List<QuestionWrapper> getquizques(Long quizId);


}
