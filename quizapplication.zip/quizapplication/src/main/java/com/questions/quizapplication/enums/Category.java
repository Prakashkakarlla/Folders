package com.questions.quizapplication.enums;

public enum Category {

	JAVA,
	SPRING,
	GIT,
	SPRING_BOOT
}
