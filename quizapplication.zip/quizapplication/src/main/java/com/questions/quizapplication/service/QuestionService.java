package com.questions.quizapplication.service;

import java.util.List;

import com.questions.quizapplication.entities.Question;

public interface QuestionService {
	
	
	Question addQues(Question que);
	
	List<Question> getAllQues();
	
	Question updateQues(Long id, Question que);

	void deleque(Long id);
	
}
