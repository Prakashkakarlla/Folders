package com.questions.quizapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
