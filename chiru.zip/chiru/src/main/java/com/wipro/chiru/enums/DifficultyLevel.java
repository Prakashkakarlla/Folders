package com.wipro.chiru.enums;

public enum DifficultyLevel {

	EASY,
	MEDIUM,
	HARD
}
