package com.wipro.chiru.enums;

public enum Category {
	
	JAVA,
	SPRING,
	GIT,
	SPRING_BOOT

}
