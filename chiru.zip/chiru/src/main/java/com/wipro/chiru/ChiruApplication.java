package com.wipro.chiru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChiruApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChiruApplication.class, args);
	}

}
