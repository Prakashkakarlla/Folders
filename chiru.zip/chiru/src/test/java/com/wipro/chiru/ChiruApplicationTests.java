package com.wipro.chiru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChiruApplicationTests {

	@Test
	void contextLoads() {
	}

}
